import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PhoneBoard Project',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PhoneBoardPage(),
    );
  }
}

class PhoneBoardPage extends StatefulWidget {
  @override
  _PhoneBoardPageState createState() => _PhoneBoardPageState();
}

class _PhoneBoardPageState extends State<PhoneBoardPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PhoneBoard Project'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            // Grid of smaller buttons (Button 1 - Button 6)
            Expanded(
              flex: 3,
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 12.0,
                  mainAxisSpacing: 12.0,
                  childAspectRatio: 1.5, // Slightly smaller buttons
                ),
                itemCount: 6,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      // Handle button press (currently no functionality)
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(color: Colors.grey, width: 1.5),
                      ),
                      child: Center(
                        child: Text(
                          'Button ${index + 1}',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 14.0), // Font size back to 14
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // Record Button (2x bigger)
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: GestureDetector(
                onTap: () {
                  // Add record logic here (no functionality yet)
                },
                child: Container(
                  height: 160.0, // Increased size for the record button
                  width: 160.0,  // Increased size for the record button
                  decoration: BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 10.0,
                        spreadRadius: 3.0,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Record\nButton\n(Max 10s)',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16.0, // Larger font size
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
