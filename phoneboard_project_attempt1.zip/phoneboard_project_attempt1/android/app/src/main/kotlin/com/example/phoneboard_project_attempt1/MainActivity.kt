package com.example.phoneboard_project_attempt1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
